package com.example.demo.SP;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Student;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    public boolean signup(Student student) {
        try {
            studentRepository.save(student);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public String signIn(Student student) {
        Student studentoptional = studentRepository.findByEmailAndPassword(student.getEmail(), student.getPassword());
        if (student!= null) {
                JwtUtil token = new JwtUtil();
                String generatedToken = token.generateToken(studentoptional.getId());
                return generatedToken;
        }
        return null;
    }
}