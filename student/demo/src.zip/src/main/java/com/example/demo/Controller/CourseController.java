package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Course;
import com.example.demo.Entity.courseEnrollment;
import com.example.demo.SP.CourseService;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping("/allCourses")
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/getCoursebyId/{courseId}")
    public Course getCourseById(@PathVariable int courseId) {
        return courseService.getCourseById(courseId);
    }

    @GetMapping("/searchByName")
    public List<Course> searchCoursesByName(@RequestParam String keyword) {
        return courseService.searchCoursesByName(keyword);
    }

    @GetMapping("/searchByCategory")
    public List<Course> searchCoursesByCategory(@RequestParam String category) {
        return courseService.searchCoursesByCategory(category);
    }

    @GetMapping("/sortedByRating")
    public List<Course> getCoursesSortedByRating() {
        return courseService.getCoursesSortedByRating();
    }

    @GetMapping("/viewCourseInfo/{courseId}")
    public Optional<Course> viewCourseInformation(@PathVariable int courseId) {
        return courseService.viewCourseInformation(courseId);
    }

    @GetMapping("/getEnrollments/{userId}")
    public List<courseEnrollment> getEnrollmentsForUser(@PathVariable int userId) {
        return courseService.getEnrollmentsForUser(userId);
    }

    @PostMapping("/enroll")
    public String enrollStudent(@RequestParam int courseId,@RequestHeader("Authorization") String token) {

        // Enroll the student using the token and courseId
        boolean enrolled = courseService.enrollStudent(token, courseId);
        if (enrolled) {
            return "Enrollment successful";
        } else {
            return "Enrollment failed";
        }
    }

    @DeleteMapping("/cancelEnrollment/{enrollmentId}")
    public String cancelEnrollment(@PathVariable int enrollmentId) {
        boolean canceled = courseService.cancelEnrollment(enrollmentId);
        if (canceled) {
            return "Cancellation successful";
        } else {
            return "Cancellation failed";
        }
    }
}
