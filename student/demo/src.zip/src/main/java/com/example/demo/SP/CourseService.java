    package com.example.demo.SP;
    import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
    import java.util.Optional;

    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Service;
    import org.springframework.transaction.annotation.Transactional;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.example.demo.Entity.Course;
    import com.example.demo.Entity.courseEnrollment;

    @Service
    public class CourseService {
    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private CourseEnrollmentRepository courseEnrollmentRepository;
    @Autowired
    private JwtUtil jwtUtil;
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Course getCourseById(int courseId) {
        return courseRepository.findById(courseId).orElse(null);
    }

    public List<Course> searchCoursesByName(String keyword) {
        return courseRepository.findByCourseNameContainingIgnoreCase(keyword);
    }

    public List<Course> searchCoursesByCategory(String category) {
        return courseRepository.findByCategoryIgnoreCase(category);
    }

    public List<Course> getCoursesSortedByRating() {
        return courseRepository.findByOrderByRatingDesc();
    }
    @Transactional(readOnly = true)
    public Optional<Course> viewCourseInformation(int courseId) {
        return courseRepository.findById(courseId);
    }
    @Transactional(readOnly = true)
    public List<courseEnrollment> getEnrollmentsForUser(int userId) {
        return courseEnrollmentRepository.findByStudentId(userId);
    }
    @Transactional
    public boolean enrollStudent(String token, int courseId) {
        try {
            DecodedJWT decodedJWT = jwtUtil.decodeToken(token);
            int studentId = decodedJWT.getClaim("id").asInt();
            if (studentId == 0) {
                return false; // Token parsing failed or student ID not found in token
            }

            Course course = courseRepository.findById(courseId).orElse(null);
            if (course == null || course.getCurrentCapacity() >= course.getMaxCapacity()) {
                return false; // Course not found or capacity full
            }

            courseEnrollment enrollment = new courseEnrollment();
            enrollment.setStudent(studentId); // Convert to integer if needed
            enrollment.setCourse(courseId);
            LocalDateTime enrollmentDateTime = LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault());
            enrollment.setEnrollmentDate(enrollmentDateTime);
            enrollment.setStatus("enrolled");

            courseEnrollmentRepository.save(enrollment);
            course.setCurrentCapacity(course.getCurrentCapacity() + 1);
            courseRepository.save(course);

            return true; // Enrollment successful
        } catch (Exception e) {
            // Handle any exceptions here
            return false;
        }
    }

    @Transactional
    public boolean cancelEnrollment(int enrollmentId) {
        courseEnrollment enrollment = courseEnrollmentRepository.findById(enrollmentId).orElse(null);
        if (enrollment == null) {
            return false; // Enrollment not found
        }

        Course course = courseRepository.findById(enrollment.getCourse()).orElse(null);
        if (course == null) {
            return false; // Course not found
        }

        course.setCurrentCapacity(course.getCurrentCapacity() - 1);
        courseRepository.save(course);
        courseEnrollmentRepository.deleteById(enrollmentId);

        return true; // Cancellation successful
    }
}
